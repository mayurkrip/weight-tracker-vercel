import { useState } from "react";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(LineElement, CategoryScale, LinearScale, PointElement, Tooltip, Legend);

export default function WeightLossTracker() {
  const [entries, setEntries] = useState([]);
  const [kateInput, setKateInput] = useState({ change: "", note: "" });
  const [mayurInput, setMayurInput] = useState({ change: "", note: "" });

  const handleSubmit = () => {
    const today = new Date().toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });

    setEntries([
      ...entries,
      {
        date: today,
        kateChange: parseFloat(kateInput.change) || 0,
        kateNote: kateInput.note,
        mayurChange: parseFloat(mayurInput.change) || 0,
        mayurNote: mayurInput.note,
      },
    ]);

    setKateInput({ change: "", note: "" });
    setMayurInput({ change: "", note: "" });
  };

  const dates = entries.map((e) => e.date);
  const kateData = entries.reduce((acc, e, i) => {
    acc.push((acc[i - 1] || 0) + e.kateChange);
    return acc;
  }, []);
  const mayurData = entries.reduce((acc, e, i) => {
    acc.push((acc[i - 1] || 0) + e.mayurChange);
    return acc;
  }, []);

  const chartData = {
    labels: dates,
    datasets: [
      {
        label: "Kate",
        data: kateData,
        borderColor: "#f472b6",
        backgroundColor: "#f472b666",
        fill: false,
        tension: 0.4,
      },
      {
        label: "Mayur",
        data: mayurData,
        borderColor: "#60a5fa",
        backgroundColor: "#60a5fa66",
        fill: false,
        tension: 0.4,
      },
    ],
  };

  return (
    <div className="p-4 max-w-4xl mx-auto font-sans">
      <h1 className="text-3xl font-bold mb-6 text-center">Mayur & Kate's Tracker</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="bg-pink-50 p-4 rounded-xl shadow">
          <h2 className="font-semibold mb-2">Kate</h2>
          <input
            type="text"
            placeholder="Change (e.g., -0.2, +0.3)"
            className="w-full p-2 border rounded mb-2"
            value={kateInput.change}
            onChange={(e) => setKateInput({ ...kateInput, change: e.target.value })}
          />
          <textarea
            placeholder="Note (e.g., strength up, muscle gain)"
            className="w-full p-2 border rounded"
            value={kateInput.note}
            onChange={(e) => setKateInput({ ...kateInput, note: e.target.value })}
          />
        </div>

        <div className="bg-blue-50 p-4 rounded-xl shadow">
          <h2 className="font-semibold mb-2">Mayur</h2>
          <input
            type="text"
            placeholder="Change (e.g., -0.5)"
            className="w-full p-2 border rounded mb-2"
            value={mayurInput.change}
            onChange={(e) => setMayurInput({ ...mayurInput, change: e.target.value })}
          />
          <textarea
            placeholder="Note (optional)"
            className="w-full p-2 border rounded"
            value={mayurInput.note}
            onChange={(e) => setMayurInput({ ...mayurInput, note: e.target.value })}
          />
        </div>
      </div>

      <div className="text-center mb-6">
        <button
          onClick={handleSubmit}
          className="bg-gradient-to-r from-blue-500 to-pink-400 text-white px-6 py-2 rounded-xl shadow"
        >
          Submit Entry
        </button>
      </div>

      <div className="bg-white p-4 rounded-xl shadow mb-8">
        <h2 className="text-xl font-semibold mb-4">Progress Graph</h2>
        <Line data={chartData} />
      </div>

      <div className="bg-gray-50 p-4 rounded-xl shadow">
        <h2 className="text-xl font-semibold mb-4">History</h2>
        <table className="w-full border text-sm">
          <thead>
            <tr className="bg-gray-100">
              <th className="p-2 border">Date</th>
              <th className="p-2 border">Kate's Change</th>
              <th className="p-2 border">Kate's Note</th>
              <th className="p-2 border">Mayur's Change</th>
              <th className="p-2 border">Mayur's Note</th>
            </tr>
          </thead>
          <tbody>
            {entries.map((entry, idx) => (
              <tr key={idx}>
                <td className="p-2 border">{entry.date}</td>
                <td className="p-2 border">{entry.kateChange}</td>
                <td className="p-2 border">{entry.kateNote}</td>
                <td className="p-2 border">{entry.mayurChange}</td>
                <td className="p-2 border">{entry.mayurNote}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
